<?php

//include "header.htm";


echo "<br>";
echo "<b>Query Customer Transactions</b>";
echo "<br>";

?>
<form method="post" action="bud2.php">
<tr><td><br></td><td></td><td></td></tr>
<tr>
<td>Query By</td>
<td>
<select name="fld" size="1">
	<option value="dat">Date</option>
	<option value="nam">Name</option>
	<option value="customerid">Connection No.</option>
	<option value="telno">Tel No.</option>
	<option value="tcode">Transaction Code</option>
</select>
</td>

<td><input type="text" name="dat"></td>
</tr>

<input type="submit"   value="Query">
</form>
</table>

<?php
// echo "<br> <a href='javascript:history.back(1)'><img src='BACK.BMP' width='12' height='16' border='0' alt=''><img src='back2.gif' width='47' height='16' border='0' alt=''></a>" ;
// include "footer.htm";
?>
